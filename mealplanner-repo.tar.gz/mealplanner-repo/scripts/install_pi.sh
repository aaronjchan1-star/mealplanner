#!/usr/bin/env bash
# Install script for Raspberry Pi Zero W (Raspberry Pi OS Bookworm or Bullseye, 32-bit ARMv6).
# Run from the project root: bash scripts/install_pi.sh

set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
echo "==> project at $PROJECT_DIR"

# 1. System deps. Pi Zero W is ARMv6 — use system python (3.9+ on Bookworm)
echo "==> installing system packages"
sudo apt-get update
sudo apt-get install -y python3 python3-venv python3-pip sqlite3

# 2. Virtualenv
if [[ ! -d "$PROJECT_DIR/.venv" ]]; then
  echo "==> creating venv"
  python3 -m venv "$PROJECT_DIR/.venv"
fi

# 3. Python deps. Pi Zero W is ARMv6 — wheels are scarce. Pull from piwheels.
PIP="$PROJECT_DIR/.venv/bin/pip"
"$PIP" install --upgrade pip wheel
"$PIP" install --extra-index-url https://www.piwheels.org/simple -r "$PROJECT_DIR/requirements.txt"

# 4. Config
if [[ ! -f "$PROJECT_DIR/config.py" ]]; then
  echo "==> creating config.py from example"
  cp "$PROJECT_DIR/config.example.py" "$PROJECT_DIR/config.py"
  echo "    EDIT $PROJECT_DIR/config.py and set ANTHROPIC_API_KEY before continuing."
fi

# 5. Data dir
mkdir -p "$PROJECT_DIR"
[[ -f "$PROJECT_DIR/data.db" ]] || touch "$PROJECT_DIR/data.db"

# 6. systemd
echo "==> installing systemd unit"
sudo cp "$PROJECT_DIR/systemd/mealplanner.service" /etc/systemd/system/mealplanner.service
sudo systemctl daemon-reload
sudo systemctl enable mealplanner.service

cat <<MSG

==> done.

Next:
  1. Edit $PROJECT_DIR/config.py and set ANTHROPIC_API_KEY (or put it in .env).
  2. Start the service:
       sudo systemctl start mealplanner
       sudo systemctl status mealplanner
  3. Open http://<pi-ip>:8080 from your phone or laptop.

To follow logs:
  journalctl -u mealplanner -f
MSG
